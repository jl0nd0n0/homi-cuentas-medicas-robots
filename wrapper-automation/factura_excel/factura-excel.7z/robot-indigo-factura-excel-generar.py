from dotenv import load_dotenv
import os
import sys
# Get the absolute path of the parent folder
parent_folder = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Add the parent folder to sys.path
sys.path.append(parent_folder)

import pyautogui
from core import robotClick
import time
from pywinauto import Application
import uiautomation as auto

import mysql.connector

if len(sys.argv) == 1:
    print("Se requiere como parametro la factura")
    sys.exit()

factura = sys.argv[1]

path = r"C:\archivos\proyectos\cartera\armado\facturas_detalle"

file_path = path + rf"\{factura}.xlsx"

#print (file_path)

# Cargar variables de entorno desde el archivo .env
# Obtener la ruta absoluta del archivo .env en el directorio superior
env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.env')
# print(env_path)
load_dotenv(env_path)

# Configuración de la conexión a la base de datos usando variables de entorno
db_config = {
    "host": os.getenv("DB_HOST"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME")
}

def robotClick(x, y, delay, descripcion=""):
    print(f"Click en ({x}, {y}) - {descripcion}")
    pyautogui.moveTo(x, y)
    pyautogui.click()
    time.sleep(delay)


def actualizar_generado(factura):
    """
    Actualiza el campo 'generado' a 1 para la factura especificada.
    
    :param factura: El número de factura a actualizar.
    """
    try:
        # Conectar a la base de datos
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # Consulta SQL para actualizar el campo 'generado'
        query = """
            UPDATE soporte_generar
            SET generado = 1
            WHERE numero_factura = %s
            and soporte = 'factura-excel'
        """
        # Ejecutar la consulta con el parámetro de la factura
        cursor.execute(query, (factura,))
        connection.commit()

        # Verificar si se realizó la actualización
        if cursor.rowcount > 0:
            print(f"El campo 'generado' ha sido actualizado a 1 para la factura {factura}.")
        else:
            print(f"No se encontró ninguna factura con el número {factura}.")

    except mysql.connector.Error as err:
        print(f"Error al conectar o actualizar en la base de datos: {err}")
    finally:
        # Cerrar la conexión a la base de datos
        if 'connection' in locals() and connection.is_connected():
            cursor.close()
            connection.close()
            print("Conexión a la base de datos cerrada.")

# Find a window by its title
window = auto.WindowControl(searchDepth=1, AutomationId="FormMdi")
if  not window.Exists():
    print("La ventana no existe !!!")
 
window.SetActive()
time.sleep(1) 

if os.path.exists(file_path):
    print(f"El archivo {file_path} ya existe !!!")
    actualizar_generado(factura)
    sys.exit()

# #click boton cerrar vista previalzacion factura
# robotClick(1260, 64,0.5, "cerrar previsualizacion factura")

# #click icono indigo
# robotClick(25, 34, 1, "Icono Indigo")
#click boton Vie RCM
robotClick(83, 253, 1, "Opcion vie RCM")
#click boton glosas
robotClick(342, 199,1,"Opcion glosas")
#click boton Trazabilidad de factura
robotClick(1145, 602, 8, "trazabilidad de factura")

#click input texto factura
pyautogui.doubleClick(476, 291)
#ingreso numero de factura
auto.SendKeys(factura)
auto.SendKeys("{Enter}") 


time.sleep(8)
#click opcion de soporte factura
robotClick(483, 614,1,"opcion soporte factura")
time.sleep(12)

#click codificacion servicio select
robotClick(356, 151,1,"codificacion servicio select")
#click codificacion servicio (manual tarifa)
robotClick(356, 169,1,"codificacion servicio (manual tarifa)")
#click codificacion producto select
robotClick(354, 199,1,"codificacion producto select")
#click codificacion producto (codigo cum)
robotClick(358, 258,1,"codificacion producto (codigo cum)")
#click boton enviar
robotClick(356, 297,1,"boton enviar")



#guardado de archivo
#click boton tipo guarda
robotClick(874, 44,1,"tipo de guardado")
time.sleep(0.5)
#click select opcion pdf guardado
robotClick(913, 189,1,"select opcion pdf guardado")
#click boton aceptar
robotClick(736, 470,1,"boton aceptar guardado")



#input windows ruta soporte
pyautogui.doubleClick(579, 362)
time.sleep(0.5)
#input insertar ruta de archivo con nombre
auto.SendKeys(file_path)


auto.SendKeys("{Enter}") 

#click boton no abrir
time.sleep(2)
robotClick(738, 416,1,"boton no abrir")
robotClick(905, 41,1,"boton no abrir")
robotClick(1348, 63,1,"boton no abrir")

actualizar_generado(factura)

# try:
#     print("\nMostrando posición del mouse. Presiona Ctrl + C para salir.\n")
#     while True:
#         x, y = pyautogui.position()
#         print(f"Posición actual: ({x}, {y})", end='\r')
#         time.sleep(0.1)
# except KeyboardInterrupt:
#     print("\nDetenido por el usuario.")
# sys.exit()






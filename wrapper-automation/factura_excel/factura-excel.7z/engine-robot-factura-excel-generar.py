import subprocess
import mysql.connector
from dotenv import load_dotenv
import os
import sys

# Cargar variables de entorno desde el archivo .env
# Obtener la ruta absoluta del archivo .env en el directorio superior
env_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '.env')
# print(env_path)
load_dotenv(env_path)

#print(os.getenv("DB_HOST"))
#sys.exit()

# Configuración de la conexión a la base de datos usando variables de entorno
db_config = {
    "host": os.getenv("DB_HOST"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME")
}

# Consulta SQL para filtrar registros
query = """
    SELECT numero_factura as factura
    FROM soporte_generar
    WHERE soporte = 'factura-excel'
      AND IFNULL(generado, 0) = 0;
"""

try:
    # Conectar a la base de datos
    connection = mysql.connector.connect(**db_config)
    cursor = connection.cursor()

    # Ejecutar la consulta
    cursor.execute(query)
    results = cursor.fetchall()

    # Iterar sobre los resultados
    for row in results:
        factura = row[0]  # Recuperar el número de factura
        print(f"Procesando factura: {factura}")

        # Llamar al script robot_rips_json_generar.py con la factura como parámetro
        subprocess.run(["python", "robot-indigo-factura-excel-generar.py", str(factura)])
    
    #print("Ejecutando sincronización con rclone...")
    #subprocess.run(["rclone", "copy", "C:\archivos\proyectos\cartera\armado\facturas_detalle", "nombre_remoto:ruta/remota", "--progress"])

except mysql.connector.Error as err:
    print(f"Error al conectar a la base de datos: {err}")
except Error as err: 
    print(f"{err}")
finally:
    # Cerrar la conexión a la base de datos
    if 'connection' in locals() and connection.is_connected():
        cursor.close()
        connection.close()
        print("Conexión a la base de datos cerrada.")
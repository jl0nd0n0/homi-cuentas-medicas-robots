import openpyxl
import csv
import sys
import time

# Registrar el tiempo de inicio
inicio = time.time()

# Configuración del archivo Excel
file_name = "facturas-dia.xlsx"
sheet_name = "Sheet"
columna_centro_atencion = "Centro atención"
columna_factura = "No. Factura"
columna_cliente = "Cliente"  # Nueva columna
columna_fecha = "Fecha"
columna_nit = "NIT"
columna_paciente = "Paciente"
columna_valor = "Valor"
columna_tipo_documento = "Tipo Documento"
columna_facturador = "Facturador"


# Configuración del archivo CSV
csv_file_name = "facturas-dia.csv"

# Cargar el archivo Excel
try:
    workbook = openpyxl.load_workbook(file_name)
except FileNotFoundError:
    print(f"Error: El archivo '{file_name}' no fue encontrado.")
    exit(1)

# Acceder a la hoja específica
if sheet_name not in workbook.sheetnames:
    print(f"Error: La hoja '{sheet_name}' no existe en el archivo Excel.")
    exit(1)

sheet = workbook[sheet_name]

# Leer la fila de encabezados (fila 8)
header_row = list(sheet.iter_rows(min_row=8, max_row=8, values_only=True))[0]

# Verificar columnas requeridas
for col in [columna_factura, columna_cliente]:
    if col not in header_row:
        print(f"Error: La columna '{col}' no existe en la hoja.")
        exit(1)

# Obtener índices de las columnas
index_centro_atencion = header_row.index(columna_centro_atencion)
index_factura = header_row.index(columna_factura)
index_cliente = header_row.index(columna_cliente)
index_fecha = header_row.index(columna_fecha)
index_nit =  header_row.index(columna_nit)
index_valor = header_row.index(columna_valor)

print(index_valor)


# Abrir el archivo CSV para escribir los datos
with open(csv_file_name, mode="w", newline="", encoding="utf-8") as csv_file:
    writer = csv.writer(csv_file, delimiter=';')    

    # Escribir el encabezado del CSV
    writer.writerow(["centro_atencion", "numero_factura", "fecha", "cliente", "nit", "valor"])

    # Iterar sobre las filas del archivo Excel (comenzando desde la fila 9)
    for row in sheet.iter_rows(min_row=9, values_only=True):
        val_centro_atencion = row[index_centro_atencion]
        val_factura = row[index_factura]
        val_fecha = row[index_fecha]
        val_cliente = row[index_cliente]        
        val_nit = row[index_nit]
        val_valor = row[index_valor]
        
        print(val_valor)
        sys.exit()

        if val_factura is not None:
            writer.writerow([val_centro_atencion, val_factura, val_fecha, val_cliente, val_nit, val_valor])

print(f"Los datos han sido exportados exitosamente al archivo '{csv_file_name}'.")

# Mostrar duración
fin = time.time()
duracion_segundos = fin - inicio
minutos = int(duracion_segundos // 60)
segundos = int(duracion_segundos % 60)
print(f"El script tardó {minutos} minutos y {segundos} segundos en ejecutarse.")

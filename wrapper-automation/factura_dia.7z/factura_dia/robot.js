const { exec } = require('child_process');

// Path to your batch file
const batchFilePath = 'C:\\archivos\\proyectos\\cartera\\armado\\facturas_diarias\\robot.bat';

// Execute the batch file
exec(batchFilePath, (error, stdout, stderr) => {
    if (error) {
        console.error(`Error executing batch file: ${error.message}`);
        return;
    }
    if (stderr) {
        console.error(`Batch file stderr: ${stderr}`);
        return;
    }
    console.log(`Batch file output: ${stdout}`);
});